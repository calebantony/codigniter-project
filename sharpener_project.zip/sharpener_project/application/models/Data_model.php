<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Data_model extends CI_Model 
{

	public function get_user($table,$id,$pass,$type)
	{
		$this->db->where(array('email'=>$id,'password'=>$pass,'utype'=>$type));
		$res=$this->db->get($table);
		return $res->result_array();
	}


	public function insert_data($table,$data)
    {
        $this->db->insert($table,$data);
    }

	public function get_data($table)
	{
        $res=$this->db->get($table);
		return $res->result_array();
	}

	public function get_email($email)
	{
		$this->db->where('email',$email);
		$res=$this->db->get("users");
		return $res->result_array();
	}

	
	public function data_update($table,$data,$id)
	{
        $this->db->where('empid',$id);
		$this->db->update($table,$data);
	}

	public function data_updatestatus($table,$data,$id)
	{
        $this->db->where('tid',$id);
		$this->db->update($table,$data);
	}

	public function data_updat($table,$id)
	{
        $this->db->where('empid',$id);
		$res=$this->db->get($table);
		$data=$res->result_array();
		return $data[0];
	}


	public function data_service($table,$id)
	{
        $this->db->where('srid',$id);
		$res=$this->db->get($table);
		$data=$res->result_array();
		return $data[0];
	}


	public function data_del($table,$id)
	{
        $this->db->where('empid',$id)->delete($table);
	}

	public function usr_del($table,$id)
	{
        $this->db->where('email',$id)->delete($table);
	}

	public function get_empmail($id)
	{
		
		$res4=$this->db->query('SELECT email from employee where empid = "'.$id.'" ');
		//var_dump ($res4);
		return $res4->row();
		
	}

	public function data_delevnt($table,$id)
	{
        $this->db->where('evid',$id)->delete($table);
	}
	

	public function get_idd($sub,$dept,$mobile,$usrmail)
	{
		$res=$this->db->query("select * from ticket  where usremail = '$usrmail' AND  department = '$dept'  AND  subject = '$sub'  AND  mobile = '$mobile' ");
		return $res->result_array();
	}

	public function get_seridd($sub,$mail,$mobile)
	{
		$res=$this->db->query("select * from service  where email = '$mail' AND  subj = '$sub' AND  phone = '$mobile' ");
		return $res->result_array();
	}

	public function get_Tick($tid)
	{
		$res=$this->db->query("select * from ticket  where tid = '$tid'  ");
		return $res->result_array();
	}

	public function get_wrk($srid)
	{
		$res=$this->db->query("select * from work  where srid = '$srid'  ");
		return $res->result_array();
	}




	public function work_view()
	{
	  $this->db->select('service.srid,service.subj,service.stype,service.phone,service.descrip,work.wstatus,work.wdate,employee.fname,employee.email');
	  $this->db->from('work');
	  $this->db->join('service', 'work.srid = service.srid');
	  $this->db->join('employee', 'work.empid = employee.empid');

	  $result = $this->db->get()->result_array();
	  //var_dump($result);
	  return $result;
	}




	function getbanklist() {
		$this->db->select("empid,fname");
		$this->db->from('employee');
		$query = $this->db->get();
		return $query;
	}

}
