<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>sharpenertechnologyservices</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="<?php echo base_url();?>assets/assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="<?php echo base_url();?>assets/assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="<?php echo base_url();?>assets/assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="<?php echo base_url();?>assets/assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="<?php echo base_url();?>assets/assets/css/pe-icon-7-stroke.css" rel="stylesheet" />

	
<link rel="shortcut icon" href="<?php echo base_url();?>images/favicon.png" type="image/x-icon">
<link rel="icon" href="<?php echo base_url();?>images/favicon.png" type="image/x-icon">


</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-color="blue" data-image="<?php echo base_url();?>assets/assets/img/sidebar-5.jpg">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

    	<div class="sidebar-wrapper">
            <div class="logo">
            &nbsp;
            <br>
            &nbsp;

				<!-- <span style="font-size: 25px; font-weight: bold;"><label style="color: #007bff">S</label>harpener <br> <label style="color: #007bff">T</label>echnology</span> -->
            </div>

            <ul class="nav">
                <li >
                    <a href="dashboard.html">
                        <i class="pe-7s-graph"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li class="active">
                    <a href="<?php echo base_url();?>Welcome/custser">
                    <i class="pe-7s-note2"></i>
                        <p> Service Request  </p>
                    </a>
                </li>

                <li  >
                    <a href="<?php echo base_url();?>Welcome/custiket">
                    <i class="pe-7s-news-paper"></i>
                        <p>Open Ticket </p>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url();?>Welcome/cusvietik">
                    <i class="pe-7s-note2"></i>
                        <p>View  tickets </p>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url();?>Welcome/cusvietikstatus">
                        <i class="pe-7s-news-paper"></i>
                        <p>Ticket status</p>
                    </a>
                </li>
               
				<!-- <li class="active-pro">
                    <a href="upgrade.html">
                        <i class="pe-7s-rocket"></i>
                        <p>Upgrade to PRO</p>
                    </a>
                </li> -->
            </ul>
    	</div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed-top">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
					<span style="font-size: 25px; font-weight: bold; color: #808080  "><label style="color: #007bff">S</label>harpener  <label style="color: #007bff">T</label>echnology</span>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-left">
                        
                       
                       
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                        <!-- <li>
                           <a href="">
                               <p>Account</p>
                            </a>
                        </li>
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <p>
										Dropdown
										<b class="caret"></b>
									</p>

                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Action</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something</a></li>
                                <li class="divider"></li>
                                <li><a href="#">Separated link</a></li>
                              </ul>
                        </li> -->
                        <li>
                            <a href="#">
                                <p>Log out</p>
                            </a>
                        </li>
						<li class="separator hidden-lg"></li>
                    </ul>
                </div>
            </div>
        </nav>


      














        &nbsp;
            <br>
            <br>
            
            &nbsp;
        
      
            <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="header">
                                <h4 style=" font-family:verdana;" class="title">Submit Request </h4>
                            </div>
                            <div class="content">
                           

                            <!-- <form method="POST" action= "<?=base_url('store-image')?>" enctype="multipart/form-data"> -->
                                <form method="POST" action="<?php echo base_url();?>Welcome/cuserreg">
                                 

                                <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Subject </label>
                                                <input type="text" class="form-control" placeholder="Enter the Subject here " name="subj">
                                               
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Related Service</label>
                                                <input type="text" class="form-control" placeholder="Enter title  " name="relaser" >
                                            </div>
                                        </div>
                                    </div>

                                   
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label> Phone number</label>
                                                <input type="number" class="form-control" placeholder="Enter your  Name " name="phone" >
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Email </label>
                                                <input type="email" class="form-control" placeholder="Email address" name="email">
                                            </div>
                                        </div>
                                    </div>

                                    
                                

                                   



                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label> Description</label>
                                                <textarea rows="5" class="form-control" placeholder="Here can be your description" name="descr"></textarea>
                                            </div>
                                        </div>
                                    </div>

                                    <button type="submit" value="Upload Image" class="btn btn-info btn-fill pull-left">Submit</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                   

                </div>
            </div>
        </div>
              

            


       

    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="<?php echo base_url();?>assets/assets/js/jquery.3.2.1.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url();?>assets/assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Charts Plugin -->
	<script src="<?php echo base_url();?>assets/assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="<?php echo base_url();?>assets/assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="<?php echo base_url();?>assets/assets/js/light-bootstrap-dashboard.js?v=1.4.0"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="<?php echo base_url();?>assets/assets/js/demo.js"></script>

	
</html>
