<?php include('header.php');?>
	
	<!--Page Title-->
    <section class="page-title">
		<div class="pattern-layer-one" style="background-image: url(<?php echo base_url();?>images/background/pattern-16.png)"></div>
    	<div class="auto-container">
			<h2>About us</h2>
			<ul class="page-breadcrumb">
				<li><a href="index-2.html">home</a></li>
				<li>About us</li>
			</ul>
        </div>
    </section>
    <!--End Page Title-->
	
	<!-- About Section -->
	<section class="about-section">
		<div class="auto-container">
			<!-- Sec Title -->
			<div class="sec-title">
				<div class="title">ABOUT COMPANY</div>
				<h2>You Can not Use Up <br> Creativity.</h2>
			</div>
			<div class="row clearfix">
				
				<!-- Content Column -->
				<div class="content-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="text">Does any industry face a more complex audience journey and marketing sales process than B2B technology? Consider the number of people who influence a sale, the length of the decision-making cycle, the competing interests of the people who purchase, implement, manage, and use the technology. It’s a lot meaningful content here.</div>
						<div class="blocks-outer">
						
							<!-- Feature Block -->
							<div class="feature-block">
								<div class="inner-box">
									<div class="icon flaticon-award-1"></div>
									<h6>Experience</h6>
									<div class="feature-text">Our great team of more than 1400 software experts.</div>
								</div>
							</div>
							
							<!-- Feature Block -->
							<div class="feature-block">
								<div class="inner-box">
									<div class="icon flaticon-technical-support"></div>
									<h6>Quick Support</h6>
									<div class="feature-text">We’ll help you test bold new ideas while sharing your.</div>
								</div>
							</div>
							
						</div>
						
					
						
					</div>
				</div>
				
				<!-- Images Column -->
				<div class="images-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column" style="background-image: url(<?php echo base_url();?>images/icons/globe.png)">
						<div class="pattern-layer" style="background-image: url(<?php echo base_url();?>images/background/pattern-1.png)"></div>
						<div class="images-outer parallax-scene-1">
							<div class="image" data-depth="0.10">
								<img src="<?php echo base_url();?>images/resource/about-1.jpg" alt="" />
							</div>
							<div class="image-two" data-depth="0.30">
								<img src="<?php echo base_url();?>images/resource/about-2.jpg" alt="" />
							</div>
							<div class="image-three" data-depth="0.20">
								<img src="<?php echo base_url();?>images/resource/about-3.jpg" alt="" />
							</div>
							<div class="image-four" data-depth="0.30">
								<img src="<?php echo base_url();?>images/resource/about-4.jpg" alt="" />
							</div>
						</div>
					</div>
					<a href="about-2.html" class="learn"><span class="arrow flaticon-long-arrow-pointing-to-the-right"></span>Learn More About Company</a>
				</div>
				
			</div>
		</div>
	</section>
	<!-- End About Section -->
	
	<!-- Counter Section -->
	<section class="counter-section">
		<div class="auto-container">
			<div class="inner-container">
				<!-- Fact Counter -->
				<div class="fact-counter">
					<div class="row clearfix">

						<!-- Column -->
						<div class="column counter-column col-lg-3 col-md-6 col-sm-12">
							<div class="inner wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
								<div class="content">
									<div class="count-outer count-box">
										<span class="count-text" data-speed="3000" data-stop="330">0</span>+
									</div>
									<h4 class="counter-title">ACTIVE CLIENTS</h4>
								</div>
							</div>
						</div>

						<!-- Column -->
						<div class="column counter-column col-lg-3 col-md-6 col-sm-12">
							<div class="inner wow fadeInLeft" data-wow-delay="300ms" data-wow-duration="1500ms">
								<div class="content">
									<div class="count-outer count-box alternate">
										<span class="count-text" data-speed="5000" data-stop="850">0</span>+
									</div>
									<h4 class="counter-title">PROJECTS DONE</h4>
								</div>
							</div>
						</div>

						<!-- Column -->
						<div class="column counter-column col-lg-3 col-md-6 col-sm-12">
							<div class="inner wow fadeInLeft" data-wow-delay="600ms" data-wow-duration="1500ms">
								<div class="content">
									<div class="count-outer count-box">
										<span class="count-text" data-speed="2000" data-stop="25">0</span>+
									</div>
									<h4 class="counter-title">TEAM ADVISORS</h4>
								</div>
							</div>
						</div>

						<!-- Column -->
						<div class="column counter-column col-lg-3 col-md-6 col-sm-12">
							<div class="inner wow fadeInLeft" data-wow-delay="900ms" data-wow-duration="1500ms">
								<div class="content">
									<div class="count-outer count-box">
										<span class="count-text" data-speed="3500" data-stop="10">0</span>+
									</div>
									<h4 class="counter-title">GLORIOUS YEARS</h4>
								</div>
							</div>
						</div>

					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Counter Section -->
	
	<!-- About Section Two -->

	<!-- End About Section Two -->
	
	<!--Sponsors Section-->
	
	<!--End Sponsors Section-->
	

	<!-- End Process Section -->
	

	<!-- End Technology Section -->
	
	<!-- Experiance Section -->
	
	<!-- End Experiance Section -->
	
	<!-- Info Section -->

	<!-- End Info Section -->
	
	<!-- Main Footer -->
     <footer class="main-footer">
		<div class="pattern-layer-one" style="background-image: url(<?php echo base_url();?>images/background/pattern-7.png)"></div>
		<div class="pattern-layer-two" style="background-image: url(<?php echo base_url();?>images/background/pattern-8.png)"></div>
		<!--Waves end-->
    	<div class="auto-container">
        	<!--Widgets Section-->
            <div class="widgets-section">
            	<div class="row clearfix">
                	
                    <!-- Column -->
                    <div class="big-column col-lg-6 col-md-12 col-sm-12">
						<div class="row clearfix">
						
                        	<!-- Footer Column -->
                            <div class="footer-column col-lg-7 col-md-6 col-sm-12">
                                <div class="footer-widget logo-widget">
									<div class="logo">
										</a>
									</div>
									<div class="text">We are the best world Information Technology Company. Providing the highest quality in hardware & Network solutions. About more than 25 years of experience and 1000 of innovative achievements.</div>
									<!-- Social Box -->
									<ul class="social-box">
										<li><a href="#" class="fa fa-facebook-f"></a></li>
										<li><a href="#" class="fa fa-linkedin"></a></li>
										<li><a href="#" class="fa fa-twitter"></a></li>
										<li><a href="#" class="fa fa-google"></a></li>
									</ul>
								</div>
							</div>
							
							<!-- Footer Column -->
                            <div class="footer-column col-lg-5 col-md-6 col-sm-12">
                                <div class="footer-widget links-widget">
									<h5>Quick Links</h5>
									<ul class="list-link">
										<li><a href="#">Managed IT services</a></li>
										<li><a href="#">Cloud Services</a></li>
										<li><a href="#">IT support & helpdesk</a></li>
										<li><a href="#">Cyber security</a></li>
										<li><a href="#">Custom Software</a></li>
										<li><a href="#">Free Consultation</a></li>
										<li><a href="#">Our Business Growth</a></li>
									</ul>
								</div>
							</div>
							
						</div>
					</div>
					
					<!-- Column -->
                    <div class="big-column col-lg-6 col-md-12 col-sm-12">
						<div class="row clearfix">
							
							<!-- Footer Column -->
					
							
							<!-- Footer Column -->
							<div class="footer-column col-lg-6 col-md-6 col-sm-12">
								<div class="footer-widget contact-widget">
									<h5>Contact Us</h5>
									<ul>
										<li>
											<span class="icon flaticon-placeholder-2"></span>
											<strong>Address</strong>
											#4/129, 1'st Main Road,Alwarthirunagar Annexe, Chennai-600 087
										</li>
										<li>
											<span class="icon flaticon-phone-call"></span>
											<strong>Phone</strong>
											<a href="tel:+786-875-864-75">+91 95000 42144</a>
										</li>
										<li>
											<span class="icon flaticon-email-1"></span>
											<strong>E-Mail</strong>
											<a href="mailto:support@sharpnertechnologies.com">support@sharpnertechnologies.com</a>
										</li>
									</ul>
								</div>
							</div>
							
						</div>
					</div>
					
				</div>
			</div>
			
			<!-- Footer Bottom -->
			<div class="footer-bottom">
				<div class="auto-container">
					<div class="row clearfix">
						<!-- Column -->
						<div class="column col-lg-6 col-md-12 col-sm-12">
							<div class="copyright">Copyright &copy; 2020 . All Rights Reserved.</div>
						</div>
						<!-- Column -->
						<div class="column col-lg-6 col-md-12 col-sm-12">
							<ul class="footer-nav">
								<li><a href="#">About Us</a></li>
								<li><a href="#">Services</a></li>
								<li><a href="#">Privacy</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</footer>	
	
</div>
<!--End pagewrapper-->

<!-- Color Palate / Color Switcher -->



<!-- Search Popup -->

<!-- End Header Search -->

<!--Scroll to top-->
<?php include('footer.php');?>