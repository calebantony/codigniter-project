<?php include('header.php');?>
	


	
	
<!--===============================================================================================-->


<!--===============================================================================================-->


	<!--Page Title-->
    <section class="page-title">
		<div class="pattern-layer-one" style="background-image: url(<?php echo base_url();?>images/background/enlarged.png)"></div>
    	<div class="auto-container">
			
			<ul class="page-breadcrumb">
			<h2>Account Login</h2>
				<!-- <li>Account Login   </li> -->
				</ul>

				&nbsp;
				&nbsp;


				
				<form class="login100-form validate-form p-b-33 p-t-5"  action="<?php echo base_url();?>Welcome/log" method="post">
				<label style = "color:Red "><?php echo $us; ?>  </label>
<div class="wrap-input100 validate-input" data-validate = "Enter username">
	<input class="input100" type="text" name="username" placeholder="User name">
	<span class="focus-input100" ></span>
</div>

<div class="wrap-input100 validate-input" data-validate="Enter password">
	<input class="input100" type="password" name="pass" placeholder="Password">
	<span class="focus-input100" ></span>
</div>
&nbsp;
&nbsp;
<div class="container-login100-form-btn m-t-32">
	<button class="login100-form-btn" type="submit">
		Login
	</button>
	&nbsp; &nbsp; &nbsp;  	&nbsp; &nbsp; &nbsp;
	<button class="login100-form-btn" type="submit" formaction="<?php echo base_url();?>Welcome/signup">
		Sign up
	</button>

</div>

&nbsp;
&nbsp;

</form>
			
			
        </div>

	

    </section>
    <!--End Page Title-->
	
	<!-- About Section -->
	
			
		



				
	
	<!-- End About Section -->
	

	
	<!-- About Section Two -->

	<!-- End About Section Two -->
	
	<!--Sponsors Section-->
	
	<!--End Sponsors Section-->
	

	<!-- End Process Section -->
	

	<!-- End Technology Section -->
	
	<!-- Experiance Section -->
	
	<!-- End Experiance Section -->
	
	<!-- Info Section -->

	<!-- End Info Section -->
	
	<!-- Main Footer -->
     <footer class="main-footer">
		<div class="pattern-layer-one" style="background-image: url(<?php echo base_url();?>images/background/pattern-7.png)"></div>
		<div class="pattern-layer-two" style="background-image: url(<?php echo base_url();?>images/background/pattern-8.png)"></div>
		<!--Waves end-->
    	<div class="auto-container">
        	<!--Widgets Section-->
            <div class="widgets-section">
            	<div class="row clearfix">
                	
                    <!-- Column -->
                    <div class="big-column col-lg-6 col-md-12 col-sm-12">
						<div class="row clearfix">
						
                        	<!-- Footer Column -->
                            <div class="footer-column col-lg-7 col-md-6 col-sm-12">
                                <div class="footer-widget logo-widget">
									<div class="logo">
										</a>
									</div>
									<div class="text">We are the best world Information Technology Company. Providing the highest quality in hardware & Network solutions. About more than 25 years of experience and 1000 of innovative achievements.</div>
									<!-- Social Box -->
									<ul class="social-box">
										<li><a href="#" class="fa fa-facebook-f"></a></li>
										<li><a href="#" class="fa fa-linkedin"></a></li>
										<li><a href="#" class="fa fa-twitter"></a></li>
										<li><a href="#" class="fa fa-google"></a></li>
									</ul>
								</div>
							</div>
							
							<!-- Footer Column -->
                            <div class="footer-column col-lg-5 col-md-6 col-sm-12">
                                <div class="footer-widget links-widget">
									<h5>Quick Links</h5>
									<ul class="list-link">
										<li><a href="#">Managed IT services</a></li>
										<li><a href="#">Cloud Services</a></li>
										<li><a href="#">IT support & helpdesk</a></li>
										<li><a href="#">Cyber security</a></li>
										<li><a href="#">Custom Software</a></li>
										<li><a href="#">Free Consultation</a></li>
										<li><a href="#">Our Business Growth</a></li>
									</ul>
								</div>
							</div>
							
						</div>
					</div>
					
					<!-- Column -->
                    <div class="big-column col-lg-6 col-md-12 col-sm-12">
						<div class="row clearfix">
							
							<!-- Footer Column -->
					
							
							<!-- Footer Column -->
							<div class="footer-column col-lg-6 col-md-6 col-sm-12">
								<div class="footer-widget contact-widget">
									<h5>Contact Us</h5>
									<ul>
										<li>
											<span class="icon flaticon-placeholder-2"></span>
											<strong>Address</strong>
											#4/129, 1'st Main Road,Alwarthirunagar Annexe, Chennai-600 087
										</li>
										<li>
											<span class="icon flaticon-phone-call"></span>
											<strong>Phone</strong>
											<a href="tel:+786-875-864-75">+91 95000 42144</a>
										</li>
										<li>
											<span class="icon flaticon-email-1"></span>
											<strong>E-Mail</strong>
											<a href="mailto:support@sharpnertechnologies.com">support@sharpnertechnologies.com</a>
										</li>
									</ul>
								</div>
							</div>
							
						</div>
					</div>
					
				</div>
			</div>
			
			<!-- Footer Bottom -->
			<div class="footer-bottom">
				<div class="auto-container">
					<div class="row clearfix">
						<!-- Column -->
						<div class="column col-lg-6 col-md-12 col-sm-12">
							<div class="copyright">Copyright &copy; 2020 . All Rights Reserved.</div>
						</div>
						<!-- Column -->
						<div class="column col-lg-6 col-md-12 col-sm-12">
							<ul class="footer-nav">
								<li><a href="#">About Us</a></li>
								<li><a href="#">Services</a></li>
								<li><a href="#">Privacy</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</footer>	
	
</div>
<!--End pagewrapper-->

<!-- Color Palate / Color Switcher -->

<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/main.css">

<!-- Search Popup -->

<!-- End Header Search -->

<!--Scroll to top-->
<?php include('footer.php');?>