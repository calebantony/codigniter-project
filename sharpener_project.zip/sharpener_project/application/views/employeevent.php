<?php
error_reporting(0);
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>sharpenertechnologyservices</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

   

    <!-- Bootstrap core CSS     -->
    <link href="<?php echo base_url();?>assets/assets/css/bootstrap.min.css" rel="stylesheet" />


    
    <!-- Animation library for notifications   -->
    <link href="<?php echo base_url();?>assets/assets/css/animate.min.css" rel="stylesheet"/>

     
    <!--  Light Bootstrap Table core CSS    -->
    <link href="<?php echo base_url();?>assets/assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>



    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="<?php echo base_url();?>assets/assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="<?php echo base_url();?>assets/assets/css/pe-icon-7-stroke.css" rel="stylesheet" />

	
<link rel="shortcut icon" href="<?php echo base_url();?>images/favicon.png" type="image/x-icon">
<link rel="icon" href="<?php echo base_url();?>images/favicon.png" type="image/x-icon">

<!-- 
<link href="<?php echo base_url();?>assets/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">  -->




<style>
a:link {
  color:  red;
  background-color: transparent;
  text-decoration: none;
}

a:visited {
  color: pink;
  background-color: transparent;
  text-decoration: none;
}

a:hover {
  color: red;
  background-color: transparent;
  text-decoration: underline;
}

a:active {
  color: yellow;
  background-color: transparent;
  text-decoration: underline;
}
</style>



</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-color="blue" data-image="<?php echo base_url();?>assets/assets/img/sidebar-5.jpg">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

    	<div class="sidebar-wrapper">
            <div class="logo">
            &nbsp;
            <br>
            &nbsp;

				<!-- <span style="font-size: 25px; font-weight: bold;"><label style="color: #007bff">S</label>harpener <br> <label style="color: #007bff">T</label>echnology</span> -->
            </div>

            <ul class="nav">
                <li class="active">
                    <a href="dashboard.html">
                        <i class="pe-7s-graph"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url();?>Welcome/empprof">
                        <i class="pe-7s-user"></i>
                        <p>Profile </p>
                    </a>
                </li>


                <li>
                    <a href="<?php echo base_url();?>Welcome/empevent">
                        <i class="pe-7s-note2"></i>
                        <p>Event</p>
                    </a>
                </li>


				<li class="dropdown">
               
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                              <i class="fa fa-edit fa-3x"></i>
                                    <p>
                                   
										Edit staff 
										<b class="caret"></b>
									</p>

                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="<?php echo base_url();?>Welcome/emplist"> STAFF LIST</a></li>
                                <li class="divider"></li>
                                <li><a href="<?php echo base_url();?>Welcome/editemp"> EDIT STAFF DETAILS </a></li>
                                <li class="divider"></li>
                                <li><a href="<?php echo base_url();?>Welcome/empdelete">REMOVE A STAFF </a></li>
                                <!-- <li class="divider"></li> -->
                              
                              </ul>
                        </li>

                        


              
                <li>
                    <a href=" xxxx ">
                        <i class="pe-7s-news-paper"></i>
                        <p>Typography</p>
                    </a>
                </li>
                <li>
                    <a href="icons.html">
                        <i class="pe-7s-science"></i>
                        <p>Icons</p>
                    </a>
                </li>
                <li>
                    <a href="maps.html">
                        <i class="pe-7s-map-marker"></i>
                        <p>Maps</p>
                    </a>
                </li>
                <li>
                    <a href="notifications.html">
                        <i class="pe-7s-bell"></i>
                        <p>Notifications</p>
                    </a>
                </li>
				<!-- <li class="active-pro">
                    <a href="upgrade.html">
                        <i class="pe-7s-rocket"></i>
                        <p>Upgrade to PRO</p>
                    </a>
                </li> -->
            </ul>
    	</div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed-top">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
					<span style="font-size: 25px; font-weight: bold; color: #808080  "><label style="color: #007bff">S</label>harpener  <label style="color: #007bff">T</label>echnology</span>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-left">
                        
                       
                       
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                        <li>
                           <a href="">
                               <p>Account</p>
                            </a>
                        </li>
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <p>
										Dropdown
										<b class="caret"></b>
									</p>

                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Action</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something</a></li>
                                <li class="divider"></li>
                                <li><a href="#">Separated link</a></li>
                              </ul>
                        </li>
                        <li>
                            <a href="#">
                                <p>Log out</p>
                            </a>
                        </li>
						<li class="separator hidden-lg"></li>
                    </ul>
                </div>
            </div>
        </nav>


      














        &nbsp;
            <br>
            <br>
            
            &nbsp;
        
      

          
            <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">EVENT  DETAILS </h4>
                                <p class="category">Here is the list of all events</p>
                            </div>
                            <div class="content table-responsive table-full-width">




             <table class="table table-hover table-striped">
                                    <thead>
                                   
                                      <th>Event </th>
                                    	<th>Date</th>
                                        <th>Time</th>
                                    	<th>Description </th>
                                    	<th> &nbsp; </th>
                                     

                                    </thead>
                                    <tbody>
                                    <?php
                        foreach($emp as $e)
                        {?>
                        <tr>
                        <td><?php echo $e['evntname'];?></td>
                        <td><?php echo $e['evntdate'];?></td>
                        <td><?php echo $e['evnttime'];?></td>
                        <td height="100"><?php echo $e['evntdesc'];?></td>
                        <td>
                         <a href ="<?php echo base_url();?>Welcome/del_evnt/<?php echo $e['evid'];?>">X</a></td>
                        </tr>
                        <?php } ?>
                                    </tbody>
                                </table>




                                



          
           <!-- </ul> -->
           <!-- <button type="button" class="w-100 btn btn-lg btn-outline-primary">Sign up for free</button> -->
     
     <!-- <div class="col">
       <div class="card mb-4 rounded-3 shadow-sm">
         <div class="card-header py-3">
           <h4 class="my-0 fw-normal">Pro</h4>
         </div>
         <div class="card-body">
           <h1 class="card-title pricing-card-title">$15<small class="text-muted fw-light">/mo</small></h1>
           <ul class="list-unstyled mt-3 mb-4">
             <li>20 users included</li>
             <li>10 GB of storage</li>
             <li>Priority email support</li>
             <li>Help center access</li>
           </ul>
           <button type="button" class="w-100 btn btn-lg btn-primary">Get started</button>
         </div>
       </div>
     </div> -->
     <!-- <div class="col">
       <div class="card mb-4 rounded-3 shadow-sm border-primary">
         <div class="card-header py-3 text-white bg-primary border-primary">
           <h4 class="my-0 fw-normal">Enterprise</h4>
         </div>
         <div class="card-body">
           <h1 class="card-title pricing-card-title">$29<small class="text-muted fw-light">/mo</small></h1>
           <ul class="list-unstyled mt-3 mb-4">
             <li>30 users included</li>
             <li>15 GB of storage</li>
             <li>Phone and email support</li>
             <li>Help center access</li>
           </ul>
           <button type="button" class="w-100 btn btn-lg btn-primary">Contact us</button>
         </div>
       </div>
     </div>
   </div> -->

  
   
              

            
                      </div>
                        </div>
                    </div>



       

    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="<?php echo base_url();?>assets/assets/js/jquery.3.2.1.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url();?>assets/assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Charts Plugin -->
	<script src="<?php echo base_url();?>assets/assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="<?php echo base_url();?>assets/assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="<?php echo base_url();?>assets/assets/js/light-bootstrap-dashboard.js?v=1.4.0"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="<?php echo base_url();?>assets/assets/js/demo.js"></script>

	<script type="text/javascript">
    	$(document).ready(function(){

        	demo.initChartist();

        	$.notify({
            	icon: 'pe-7s-gift',
            	message: "Welcome to <b>Light Bootstrap Dashboard</b> - a beautiful freebie for every web developer."

            },{
                type: 'info',
                timer: 4000
            });

    	});
	</script>

</html>
