<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->


<!DOCTYPE html><html class=''>
<head><script src='//production-assets.codepen.io/assets/editor/live/console_runner-079c09a0e3b9ff743e39ee2d5637b9216b3545af0de366d4b9aad9dc87e26bfd.js'></script><script src='//production-assets.codepen.io/assets/editor/live/events_runner-73716630c22bbc8cff4bd0f07b135f00a0bdc5d14629260c3ec49e5606f98fdd.js'></script><script src='//production-assets.codepen.io/assets/editor/live/css_live_reload_init-2c0dc5167d60a5af3ee189d570b1835129687ea2a61bee3513dee3a50c115a77.js'></script><meta charset='UTF-8'><meta name="robots" content="noindex"><link rel="shortcut icon" type="image/x-icon" href="//production-assets.codepen.io/assets/favicon/favicon-8ea04875e70c4b0bb41da869e81236e54394d63638a1ef12fa558a4a835f1164.ico" /><link rel="mask-icon" type="" href="//production-assets.codepen.io/assets/favicon/logo-pin-f2d2b6d2c61838f7e76325261b7195c27224080bc099486ddd6dccb469b8e8e6.svg" color="#111" /><link rel="canonical" href="https://codepen.io/alexkrolick/pen/gmroPj?depth=everything&order=popularity&page=34&q=react&show_forks=false" />

<link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/octicons/4.4.0/font/octicons.css'><link rel='stylesheet prefetch' href='https://unpkg.com/react-quill@1.0.0/dist/quill.core.css'><link rel='stylesheet prefetch' href='https://unpkg.com/react-quill@1.0.0/dist/quill.snow.css'>
<style class="cp-pen-styles">body {
  background: #f3f1f2;
}

.app {
  margin: 1rem auto;
  max-width: 40rem;
}

.app .ql-container {
  min-height: 10em;
  border-bottom-left-radius: 0.5em;
  border-bottom-right-radius: 0.5em;
  background: #fefcfc;
}

.app .ql-toolbar {
  background: #eaecec;
  border-top-left-radius: 0.5em;
  border-top-right-radius: 0.5em;
}</style></head><body>
<div class="app">
</div>
<script src='//production-assets.codepen.io/assets/common/stopExecutionOnTimeout-b2a7b3fe212eaa732349046d8416e00a9dec26eb7fd347590fbced3ab38af52e.js'></script><script src='https://cdnjs.cloudflare.com/ajax/libs/react/15.4.2/react.min.js'></script><script src='https://cdnjs.cloudflare.com/ajax/libs/react/15.4.2/react-dom.min.js'></script><script src='https://unpkg.com/react-quill@1.0.0/dist/react-quill.min.js'></script>
<script >"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*
 * Custom "star" icon for the toolbar using an Octicon
 * https://octicons.github.io
 */
var CustomButton = function CustomButton() {
  return React.createElement("span", { className: "octicon octicon-star" });
};

/*
 * Event handler to be attached using Quill toolbar module (see line 73)
 * https://quilljs.com/docs/modules/toolbar/
 */
function insertStar() {
  var cursorPosition = this.quill.getSelection().index;
  this.quill.insertText(cursorPosition, "★");
  this.quill.setSelection(cursorPosition + 1);
}

/*
 * Custom toolbar component including insertStar button and dropdowns
 */
var CustomToolbar = function CustomToolbar() {
  return React.createElement(
    "div",
    { id: "toolbar" },
    React.createElement(
      "select",
      { className: "ql-header" },
      React.createElement("option", { value: "1" }),
      React.createElement("option", { value: "2" }),
      React.createElement("option", { selected: true })
    ),
    React.createElement("button", { className: "ql-bold" }),
    React.createElement("button", { className: "ql-italic" }),
    React.createElement(
      "select",
      { className: "ql-color" },
      React.createElement("option", { value: "red" }),
      React.createElement("option", { value: "green" }),
      React.createElement("option", { value: "blue" }),
      React.createElement("option", { value: "orange" }),
      React.createElement("option", { value: "violet" }),
      React.createElement("option", { value: "#d0d1d2" }),
      React.createElement("option", { selected: true })
    ),
    React.createElement(
      "button",
      { className: "ql-insertStar" },
      React.createElement(CustomButton, null)
    )
  );
};

/* 
 * Editor component with custom toolbar and content containers
 */

var Editor = function (_React$Component) {
  _inherits(Editor, _React$Component);

  function Editor(props) {
    _classCallCheck(this, Editor);

    var _this = _possibleConstructorReturn(this, _React$Component.call(this, props));

    _this.state = { editorHtml: '' };
    _this.handleChange = _this.handleChange.bind(_this);
    return _this;
  }

  Editor.prototype.handleChange = function handleChange(html) {
    this.setState({ editorHtml: html });
  };

  Editor.prototype.render = function render() {
    return React.createElement(
      "div",
      { className: "text-editor" },
      React.createElement(CustomToolbar, null),
      React.createElement(
        ReactQuill,
        {
          onChange: this.handleChange,
          placeholder: this.props.placeholder,
          modules: Editor.modules,
          formats: Editor.formats,
          theme: "snow" // pass false to use minimal theme
        },
        React.createElement("div", {
          key: "editor",
          ref: "editor",
          className: "quill-contents"
        })
      )
    );
  };

  return Editor;
}(React.Component);

/* 
 * Quill modules to attach to editor
 * See https://quilljs.com/docs/modules/ for complete options
 */

Editor.modules = {
  toolbar: {
    container: "#toolbar",
    handlers: {
      "insertStar": insertStar
    }
  }
};

/* 
 * Quill editor formats
 * See https://quilljs.com/docs/formats/
 */
Editor.formats = ['header', 'font', 'size', 'bold', 'italic', 'underline', 'strike', 'blockquote', 'list', 'bullet', 'indent', 'link', 'image', 'color'];

/* 
 * PropType validation
 */
Editor.propTypes = {
  placeholder: React.PropTypes.string
};

/* 
 * Render component on page
 */
ReactDOM.render(React.createElement(Editor, { placeholder: 'Write something or insert a star ★' }), document.querySelector('.app'));
//# sourceURL=pen.js
</script>
</body></html>