<?php include('header.php');?>
	
	<!-- Banner Section -->
    <section class="banner-section">
		<div class="main-slider-carousel owl-carousel owl-theme">
            
            <div class="slide" style="background-image: url(images/main-slider/image-1.jpg)">
				<div class="patern-layer-one" style="background-image: url(images/main-slider/pattern-1.png)"></div>
				<div class="patern-layer-two" style="background-image: url(images/main-slider/pattern-2.png)"></div>
				<div class="auto-container">
					
					<!-- Content Column -->
					<div class="content-column">
						<div class="inner-column">
							<div class="patern-layer-three" style="background-image: url(images/main-slider/pattern-3.png)"></div>
							
							<h1>Sharpener Technology Provide <br> Best IT Solutions</h1>
							<div class="text">We are 50+ professional software engineers with more than <br> 10 years of experience in delivering superior products.</div>
							<div class="btns-box">
								<a href="about-2.html" class="theme-btn btn-style-one"><span class="txt">Learn More</span></a>
							</div>
						</div>
					</div>
					
				</div>
			</div>
			

			<div class="slide" style="background-image: url(images/main-slider/image-1.jpg)">
				<div class="patern-layer-one" style="background-image: url(images/main-slider/pattern-1.png)"></div>
				<div class="patern-layer-two" style="background-image: url(images/main-slider/pattern-2.png)"></div>
				<div class="auto-container">
					
					<!-- Content Column -->
					<div class="content-column">
						<div class="inner-column">
							<div class="patern-layer-three" style="background-image: url(images/main-slider/pattern-3.png)"></div>
							
							<h1>Sharpener Technology Provide <br> Best IT Solutions</h1>
							<div class="text">We are 50+ professional software engineers with more than <br> 10 years of experience in delivering superior products.</div>
							<div class="btns-box">
								<a href="about-2.html" class="theme-btn btn-style-one"><span class="txt">Learn More</span></a>
							</div>
						</div>
					</div>
					
				</div>
			</div>
			<!--<div class="slide" style="background-image: url(images/main-slider/image-1.jpg)">
				<div class="patern-layer-one" style="background-image: url(images/main-slider/pattern-1.png)"></div>
				<div class="patern-layer-two" style="background-image: url(images/main-slider/pattern-2.png)"></div>
				<div class="auto-container">
					
					<!-- Content Column -->
					<!--<div class="content-column">
						<div class="inner-column">
							<div class="patern-layer-three" style="background-image: url(images/main-slider/pattern-3.png)"></div>
							<div class="title">IT Business Consulting</div>
							<h1>Our Agency Provide <br> Best IT Solutions</h1>
							<div class="text">We are 100+ professional software engineers with more than <br> 10 years of experience in delivering superior products.</div>
							<div class="btns-box">
								<a href="about.html" class="theme-btn btn-style-one"><span class="txt">Learn More</span></a>
							</div>
						</div>
					</div>
					
				</div>
			</div>-->
			
				<!--<div class="slide" style="background-image: url(images/main-slider/image-1.jpg)">
				<div class="patern-layer-one" style="background-image: url(images/main-slider/pattern-1.png)"></div>
				<div class="patern-layer-two" style="background-image: url(images/main-slider/pattern-2.png)"></div>
				<div class="auto-container">
					
					<!-- Content Column -->
						<!--<div class="content-column">
						<div class="inner-column">
							<div class="patern-layer-three" style="background-image: url(images/main-slider/pattern-3.png)"></div>
							<div class="title">IT Business Consulting</div>
							<h1>Our Agency Provide <br> Best IT Solutions</h1>
							<div class="text">We are 100+ professional software engineers with more than <br> 10 years of experience in delivering superior products.</div>
							<div class="btns-box">
								<a href="about.html" class="theme-btn btn-style-one"><span class="txt">Learn More</span></a>
							</div>
						</div>
					</div>
					
				</div>
			</div>-->
			
		</div>
		
	</section>
	<!-- End Banner Section -->
	
	<!-- About Section -->
	<section class="about-section">
		<div class="auto-container">
			<!-- Sec Title -->
			<div class="sec-title">
				<div class="title">ABOUT COMPANY</div>
			
			</div>
			<div class="row clearfix">
				
				<!-- Content Column -->
				<div class="content-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="text">Lorem Ipsum Generator Shortcode is another best dummy content generator plugin available for WordPress. The plugin enables you to generate dummy content in posts and pages on your WordPress website. It is a very simple plugin and does not provide many options..</div>
						<div class="blocks-outer">
						
							<!-- Feature Block -->
							<div class="feature-block">
								<div class="inner-box">
									<div class="icon flaticon-award-1"></div>
									<h6>Experience</h6>
									<div class="feature-text">Lorem Ipsum Generator Shortcode is another best dummy content generator plugin available for WordPress. </div>
								</div>
							</div>
							
							<!-- Feature Block -->
							<div class="feature-block">
								<div class="inner-box">
									<div class="icon flaticon-technical-support"></div>
									<h6>Quick Support</h6>
									<div class="feature-text">The plugin enables you to generate dummy content in posts and pages on your WordPress website. It is a very simple plugin and does not provide many options.</div>
								</div>
							</div>
							
						</div>
						
					
						
					</div>
				</div>
				
				<!-- Images Column -->
				<div class="images-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column" style="background-image: url(images/icons/globe.png)">
						<div class="pattern-layer" style="background-image: url(images/background/pattern-1.png)"></div>
						<div class="images-outer parallax-scene-1">
							<div class="image" data-depth="0.10">
								<img src="images/resource/about-1.jpg" alt="" />
							</div>
							<div class="image-two" data-depth="0.30">
								<img src="images/resource/about-2.jpg" alt="" />
							</div>
							<div class="image-three" data-depth="0.20">
								<img src="images/resource/about-3.jpg" alt="" />
							</div>
							<div class="image-four" data-depth="0.30">
								<img src="images/resource/about-4.jpg" alt="" />
							</div>
						</div>
					</div>
					<a href="about-2.html" class="learn"><span class="arrow flaticon-long-arrow-pointing-to-the-right"></span>Learn More About Company</a>
				</div>
				
			</div>
		</div>
	</section>
	<!-- End About Section -->
	
	<!-- Featured Section -->
	<section class="featured-section">
		<div class="auto-container">
			<div class="row clearfix">
				
				<!-- Featured Block Two -->
				<div class="feature-block-two col-lg-6 col-md-12 col-sm-12">
					<div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms" style="background-image: url(images/resource/feature-1.jpg)">
						<div class="number">35 +</div>
						<h4>Worldwide Work Pair</h4>
						<div class="text">To succeed, every software solution must be deeply integrated into the existing tech environment..</div>
					</div>
				</div>
				
				<!-- Featured Block Two -->
				<div class="feature-block-two col-lg-6 col-md-12 col-sm-12">
					<div class="inner-box wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms" style="background-image: url(images/resource/feature-2.jpg)">
						<div class="number">40 k</div>
						<h4>Happy Clients</h4>
						<div class="text">To succeed, every software solution must be deeply integrated into the existing tech environment..</div>
					</div>
				</div>
				
			</div>
		</div>
	</section>
	<!-- End Featured Section -->
	
	<!-- Services Section -->
	<section class="services-section margin-top">
		<div class="pattern-layer" style="background-image: url(images/background/pattern-2.png)"></div>
		<div class="auto-container">
			<!-- Sec Title -->
			<div class="sec-title light centered">
				<div class="title">WHO WE ARE</div>
				<h2>We deal with the aspects of <br> professional IT Services</h2>
			</div>
			<div class="row clearfix">
				
				<!-- Service Block -->
				<div class="service-block col-lg-3 col-md-6 col-sm-12">
					<div class="inner-box">
						<div class="icon-box">
							<span class="icon flaticon-responsive"></span>
						</div>
						<h5><a href="services-detail.html">IT Soluations</a></h5>
						<div class="text">Sed ut perspiciatis unde omnis iste natus error volup validate your ideas.</div>
						<a href="services-detail.html" class="arrow flaticon-long-arrow-pointing-to-the-right"></a>
					</div>
				</div>
				
				<!-- Service Block -->
				<div class="service-block col-lg-3 col-md-6 col-sm-12">
					<div class="inner-box">
						<div class="icon-box">
							<span class="icon flaticon-monitor"></span>
						</div>
						<h5><a href="services-detail.html">Security System</a></h5>
						<div class="text">Sed ut perspiciatis unde omnis iste natus error volup validate your ideas.</div>
						<a href="services-detail.html" class="arrow flaticon-long-arrow-pointing-to-the-right"></a>
					</div>
				</div>
				
				<!-- Service Block -->
				<div class="service-block col-lg-3 col-md-6 col-sm-12">
					<div class="inner-box">
						<div class="icon-box">
							<span class="icon flaticon-coding"></span>
						</div>
						<h5><a href="services-detail.html">Web Development</a></h5>
						<div class="text">Sed ut perspiciatis unde omnis iste natus error volup validate your ideas.</div>
						<a href="services-detail.html" class="arrow flaticon-long-arrow-pointing-to-the-right"></a>
					</div>
				</div>
				
				<!-- Service Block -->
				<div class="service-block col-lg-3 col-md-6 col-sm-12">
					<div class="inner-box">
						<div class="icon-box">
							<span class="icon flaticon-laptop"></span>
						</div>
						<h5><a href="services-detail.html">Database Security</a></h5>
						<div class="text">Sed ut perspiciatis unde omnis iste natus error volup validate your ideas.</div>
						<a href="services-detail.html" class="arrow flaticon-long-arrow-pointing-to-the-right"></a>
					</div>
				</div>
				
			</div>
		</div>
	</section>
	<!-- End Services Section -->
	
	<!-- Services Section Two -->

	<!-- End Services Section Two -->
	
	<!-- Call To Action Section -->

	<!-- End Call To Action Section -->
	

	<!-- End Cases Section -->
	
	<!--Sponsors Section-->

	<!--End Sponsors Section-->
	
	<!-- Testimonial Section -->

	<!-- End Testimonial Section -->
	
	<!-- Technology Section -->
	<section class="technology-section" style="background-image: url(images/background/1.jpg)">
		<div class="pattern-layer-one" style="background-image: url(images/background/pattern-5.png)"></div>
		<div class="pattern-layer-two" style="background-image: url(images/background/pattern-6.png)"></div>
		<div class="auto-container">
			<div class="row clearfix">
				<!-- Title Column -->
				<div class="title-column col-lg-5 col-md-12 col-sm-12">
					<div class="inner-column">
						<!-- Sec Title -->
						<div class="sec-title light">
							<div class="title">TECHNOLOGY INDEX</div>
							<h2>We Deliver Solutions with the Goal of Trusting Workshops</h2>
						</div>
					</div>
				</div>
				<!-- Blocks Column -->
				<div class="blocks-column col-lg-7 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="row clearfix">
							
							<!-- Technology Block -->
							<div class="technology-block col-lg-4 col-md-6 col-sm-12">
								<div class="inner-box">
									<a href="services-detail.html" class="overlay-link"></a>
									<div class="icon-box">
										<span class="flaticon-coding-2"></span>
									</div>
									<h6>WEB</h6>
								</div>
							</div>
							
							<!-- Technology Block -->
							<div class="technology-block col-lg-4 col-md-6 col-sm-12">
								<div class="inner-box">
									<a href="services-detail.html" class="overlay-link"></a>
									<div class="icon-box">
										<span class="flaticon-android"></span>
									</div>
									<h6>ANDROID</h6>
								</div>
							</div>
							
							<!-- Technology Block -->
							<div class="technology-block col-lg-4 col-md-6 col-sm-12">
								<div class="inner-box">
									<a href="services-detail.html" class="overlay-link"></a>
									<div class="icon-box">
										<span class="flaticon-apple"></span>
									</div>
									<h6>IOS</h6>
								</div>
							</div>
							
							<!-- Technology Block -->
							<div class="technology-block col-lg-4 col-md-6 col-sm-12">
								<div class="inner-box">
									<a href="services-detail.html" class="overlay-link"></a>
									<div class="icon-box">
										<span class="flaticon-iot"></span>
									</div>
									<h6>IOT</h6>
								</div>
							</div>
							
							<!-- Technology Block -->
							<div class="technology-block col-lg-4 col-md-6 col-sm-12">
								<div class="inner-box">
									<a href="services-detail.html" class="overlay-link"></a>
									<div class="icon-box">
										<span class="flaticon-smartband"></span>
									</div>
									<h6>WEARALABLES</h6>
								</div>
							</div>
							
							<!-- Technology Block -->
							<div class="technology-block col-lg-4 col-md-6 col-sm-12">
								<div class="inner-box">
									<a href="services-detail.html" class="overlay-link"></a>
									<div class="icon-box">
										<span class="flaticon-tv"></span>
									</div>
									<h6>TV</h6>
								</div>
							</div>
							
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Technology Section -->
	

	<!-- End Team Section -->
	
	<!-- News Section -->

	<!-- End News Section -->
	
	<!-- Main Footer -->
    <footer class="main-footer">
		<div class="pattern-layer-one" style="background-image: url(images/background/pattern-7.png)"></div>
		<div class="pattern-layer-two" style="background-image: url(images/background/pattern-8.png)"></div>
		<!--Waves end-->
    	<div class="auto-container">
        	<!--Widgets Section-->
            <div class="widgets-section">
            	<div class="row clearfix">
                	
                    <!-- Column -->
                    <div class="big-column col-lg-6 col-md-12 col-sm-12">
						<div class="row clearfix">
						
                        	<!-- Footer Column -->
                            <div class="footer-column col-lg-7 col-md-6 col-sm-12">
                                <div class="footer-widget logo-widget">
									<div class="logo">
										</a>
									</div>
									<div class="text">We are the best world Information Technology Company. Providing the highest quality in hardware & Network solutions. About more than 25 years of experience and 1000 of innovative achievements.</div>
									<!-- Social Box -->
									<ul class="social-box">
										<li><a href="#" class="fa fa-facebook-f"></a></li>
										<li><a href="#" class="fa fa-linkedin"></a></li>
										<li><a href="#" class="fa fa-twitter"></a></li>
										<li><a href="#" class="fa fa-google"></a></li>
									</ul>
								</div>
							</div>
							
							<!-- Footer Column -->
                            <div class="footer-column col-lg-5 col-md-6 col-sm-12">
                                <div class="footer-widget links-widget">
									<h5>Quick Links</h5>
									<ul class="list-link">
										<li><a href="#">Managed IT services</a></li>
										<li><a href="#">Cloud Services</a></li>
										<li><a href="#">IT support & helpdesk</a></li>
										<li><a href="#">Cyber security</a></li>
										<li><a href="#">Custom Software</a></li>
										<li><a href="#">Free Consultation</a></li>
										<li><a href="#">Our Business Growth</a></li>
									</ul>
								</div>
							</div>
							
						</div>
					</div>
					
					<!-- Column -->
                    <div class="big-column col-lg-6 col-md-12 col-sm-12">
						<div class="row clearfix">
							
							<!-- Footer Column -->
					
							
							<!-- Footer Column -->
							<div class="footer-column col-lg-6 col-md-6 col-sm-12">
								<div class="footer-widget contact-widget">
									<h5>Contact Us</h5>
									<ul>
										<li>
											<span class="icon flaticon-placeholder-2"></span>
											<strong>Address</strong>
											#4/129, 1'st Main Road,Alwarthirunagar Annexe, Chennai-600 087
										</li>
										<li>
											<span class="icon flaticon-phone-call"></span>
											<strong>Phone</strong>
											<a href="tel:+786-875-864-75">+91 95000 42144</a>
										</li>
										<li>
											<span class="icon flaticon-email-1"></span>
											<strong>E-Mail</strong>
											<a href="mailto:support@sharpnertechnologies.com">support@sharpnertechnologies.com</a>
										</li>
									</ul>
								</div>
							</div>
							
						</div>
					</div>
					
				</div>
			</div>
			
			<!-- Footer Bottom -->
			<div class="footer-bottom">
				<div class="auto-container">
					<div class="row clearfix">
						<!-- Column -->
						<div class="column col-lg-6 col-md-12 col-sm-12">
							<div class="copyright">Copyright &copy; 2020 . All Rights Reserved.</div>
						</div>
						<!-- Column -->
						<div class="column col-lg-6 col-md-12 col-sm-12">
							<ul class="footer-nav">
								<li><a href="#">About Us</a></li>
								<li><a href="#">Services</a></li>
								<li><a href="#">Privacy</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</footer>	
	
</div>
<!--End pagewrapper-->

<!-- Color Palate / Color Switcher -->



<!-- Search Popup -->

<!-- End Header Search -->

<!--Scroll to top-->
<?php include('footer.php');?>