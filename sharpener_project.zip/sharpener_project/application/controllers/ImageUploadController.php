<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class ImageUploadController extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url', 'form');
    }

    public function index() {
        $this->load->view('files/upload_form');
    }

    public function store( $file_name = 'Nill') {
        $config['upload_path'] = './images/uplods';
        $config['allowed_types'] = 'gif|jpg|png|pdf';
        $config['max_size'] = 2000;
        $config['max_width'] = 1500;
        $config['max_height'] = 1500;

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('profile_image')) {
            $error = array('error' => $this->upload->display_errors());

           // $this->load->view('files/upload_form', $error);
        } else {
            $data = array('image_metadata' => $this->upload->data());
            $upload_data = $this->upload->data(); //Returns array of containing all of the data related to the file you uploaded.
           
            $file_name = $upload_data['file_name'];
         //   $this->load->view('files/upload_result', $data);
        }


        $data1=array('usrname'=>$this->input->post('name'),
        'usremail'=>$this->input->post('email'),
        'mobile'=>$this->input->post('phone'),
        'subject'=>$this->input->post('subj'),
		'department'=>$this->input->post('dept'),
		'service'=>$this->input->post('service'),
        'priority'=>$this->input->post('priority'),
		'message'=>$this->input->post('message'),
		'status'=>"open",
        'atchment'=>$file_name
		
        );
		
        $this->load->model('data_model');
		$this->data_model->insert_data("ticket",$data1);

        $usrmail=$this->input->post('email');
        $mobile=$this->input->post('phone');
        $sub=$this->input->post('subj');
		$dept=$this->input->post('dept');
        // $query = mysql_query("SELECT MAX(tid) FROM `ticket`");
        // $results = mysql_fetch_array($query);
        // $cur_auto_id = $results['MAX(tid)'] + 1;


        $info['emp']=$this->data_model->get_idd($sub,$dept,$mobile,$usrmail);
		
	
        $this->load->view('custticketSucess',$info);



    //      $query ="SELECT MAX(tid) FROM `ticket`";
	// 	 $res = $this->db->query($query);
	// 	// $data=$res->result_array();
    //     // $cur_auto_id = $data['MAX(tid)'] + 1;

    //   //  $result = mysql_query("SHOW TABLE STATUS WHERE `Name` = 'ticket'");
    //   //  $data = mysql_fetch_assoc($query);
    //     $next_increment = $res['Auto_increment'];
        
    //     echo $next_increment;

       // echo  $cur_auto_id;



    }

}


