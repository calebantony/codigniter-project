<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="TemplateMo">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700" rel="stylesheet">

    <title>Courier Management System</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url();?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/fontawesome.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/templatemo-host-cloud.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/owl.css">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.html"><h2>Ship it  <em>  Courier Management System </em></h2></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item active">
                <a class="nav-link" href="<?php echo base_url();?>Login/index">  <-  Back to Home
                  <span class="sr-only">(current)</span>
                </a>
                </li>
            
          </div>
         
      </nav>
    </header>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="banner">
      <div class="container">
        <div class="row">
          <div class="col-md-8 offset-md-2">
          <div class="container">
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-10 well well-sm">
           
            <centre>
            
   
            <h5> &nbsp</h5>
                 <h5> &nbsp</h5>
                 <h5> &nbsp</h5>

             

                 <?php
                        foreach($adr as $e)
                        {?>
                        
                        <h3>Consignment   &nbsp:  &nbsp &nbsp<?php echo $e['iname'];?> </h3>
                        <h6>&nbsp </h6>
                        <h3>Description  &nbsp &nbsp  : &nbsp &nbsp<?php echo $e['idesc'];?> </h3>
                        <h6>&nbsp </h6>
                        <h3>Quantity   &nbsp  &nbsp &nbsp &nbsp &nbsp: &nbsp &nbsp<?php echo $e['quantity'];?> </h3>
                        <h6>&nbsp </h6>
                        <h3>Category  &nbsp &nbsp &nbsp &nbsp&nbsp: &nbsp &nbsp<?php echo $e['cat'];?> </h3>
                        <h6>&nbsp </h6>
                        <h3>Status &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp&nbsp: &nbsp &nbsp<?php echo $e['status'];?> </h3>
                
    

                        
                        <?php } ?>
                        <h5>&nbsp </h5>
                        <h5>&nbsp </h5>
                        <h5>&nbsp </h5>


  
            </centre>
        </div>
    </div>
</div>
          </div>
        </div>
      </div>
    </div>
    <!-- Banner Ends Here -->

    
           



    <!-- Bootstrap core JavaScript -->
    <script src="<?php echo base_url();?>assets/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Additional Scripts -->
    <script src="<?php echo base_url();?>assets/js/custom.js"></script>
    <script src="<?php echo base_url();?>assets/js/owl.js"></script>
    <script src="<?php echo base_url();?>assets/js/accordions.js"></script>


    <script language = "text/Javascript"> 
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t){                   //declaring the array outside of the
      if(! cleared[t.id]){                      // function makes it static and global
          cleared[t.id] = 1;  // you could use true and false, but that's more typing
          t.value='';         // with more chance of typos
          t.style.color='#fff';
          }
      }
    </script>

  </body>
</html>