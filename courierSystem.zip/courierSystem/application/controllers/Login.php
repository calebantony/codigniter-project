<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	
	public function index()
	{
		$this->load->view('Home');
		//$this->load->view('empreg');
		
	}
	
	public function sig()
	{
		
		$this->load->view('signin');
	}







	public function enrate()
	{
		

		$rate=$this->input->post('rate');
		$id=$this->session->userdata('id');
		
		$this->load->model('data_model');
		$this->data_model->pymnt_update("consig",$rate,$id);

		$this->load->model('data_model');
		$info =$this->data_model->get_count1();   
		$info1 =$this->data_model->get_count5();  
		$info2 =$this->data_model->get_count3();  
		$info3 =$this->data_model->get_count4();  
		
		
		$data = array('planet' => $info,'planet1' => $info1,'planet2' => $info2,'planet3' => $info3);
      
		$this->load->view('emphome',$data);
		
	}

	public function visit()
	{
		$empmail=$this->session->userdata('employemail');
		$id=$this->uri->segment(3);
		$this->session->set_userdata('id',$id);
		$this->load->model('data_model');
		// $data['cust']=$this->data_model->get_data("bill_detail");
		$data['adr']=$this->data_model->getrate("consig",$id);
		
		// $data['updat']=$this->data_model->data_updat("employe",$id);
		$this->load->view('emprate',$data); 

		$this->load->model('data_model');
 		$eid['id']=$this->data_model->emplpickup($empmail);
 		$id3=$this->data_model->consdetid($id);
	

//    echo $id3->cnid;
//   echo $eid['id']->empid;

		$data3=array('cid'=>$id3->cnid,
        'emp'=>$eid['id']->empid,
        'type'=>'p',
		);
        $this->load->model('data_model');
        $this->data_model->insert_data("track",$data3);

	}


	public function delivupt()
	{
		$this->load->helper('date');
		
		$empmail=$this->session->userdata('employemail');
		$id=$this->uri->segment(3);
		$date4=date('y-m-d');
		// $this->session->set_userdata('id',$id);
		$this->load->model('data_model');
		// $data['cust']=$this->data_model->get_data("bill_detail");
		$data['adr']=$this->data_model->deliupdate($id,$date4);
		
		// $data['updat']=$this->data_model->data_updat("employe",$id);
		$this->load->model('data_model');

		
		$eid['id']=$this->data_model->emplpickup($empmail); //empid
		$id3=$this->data_model->consdetideli($id);  //conid


		
//     echo $id3->cnid;
//    echo $eid['id']->empid;

 	 	 $cid=$id3->cnid;
  		 $emid=$eid['id']->empid;

		
        $this->load->model('data_model');
        // $this->data_model-> deliemptrack($cid,$emid);




		$data3=array('cid'=>$cid,
        'emp'=>$emid,
        'type'=>'d',
		);
        $this->load->model('data_model');
        $this->data_model->insert_data("track",$data3);



		$this->load->model('data_model');
		$info =$this->data_model->get_count1();   
		$info1 =$this->data_model->get_count5();  
		$info2 =$this->data_model->get_count3();  
		$info3 =$this->data_model->get_count4();  
		
		
		$data = array('planet' => $info,'planet1' => $info1,'planet2' => $info2,'planet3' => $info3);
      
		$this->load->view('emphome',$data);
		 
	}




	public function admineditemp()          //load table
	{
		$this->load->model('data_model');
		$info['emp']=$this->data_model->get_data("employe");
		$this->load->view('adminedemp',$info);
		
	}
	public function del_data()             //delete
    {
        $id=$this->uri->segment(3);
        $this->load->model('data_model');
        $this->data_model->data_del("employe",$id);
        header('location:'.base_url().'Login/admineditemp');
     }


	 public function updat_cust()        //update
	 {
		 $id=$this->input->post('hid');
		 $data=array('empname'=>$this->input->post('empname'),
		 'email'=>$this->input->post('email'),
		 'empadr'=>$this->input->post('empadr'),
		 'dob'=>$this->input->post('dob'),
		 'empmobile'=>$this->input->post('empmobile'),
		 'dob'=>$this->input->post('dob'),
		 'gender'=>$this->input->post('gender'),
		 'doj'=>$this->input->post('doj'),
		 'pass'=>$this->input->post('password')
		 );
		 $this->load->model('data_model');
		 $this->data_model->data_update("employe",$data,$id);
		 header('location:'.base_url().'Login/admineditemp');
 }
 public function updat_data() //post
 {
	 $id=$this->uri->segment(3);
	 $this->load->model('data_model');
	 // $data['cust']=$this->data_model->get_data("bill_detail");
	 $data['emp']=$this->data_model->get_data("employe");
	 $data['updat']=$this->data_model->data_updat("employe",$id);
	 $this->load->view('adminedemp',$data); 

}






	public function emptrack()
	{
		
		$this->load->view('emptrackconsig');
	}

	public function pickup()
	{
		$this->load->model('data_model');
		$info['adr']=$this->data_model->get_sadr("address");
		$this->load->view('emppickup',$info);
		
	}

	public function delive()
	{
		$this->load->model('data_model');
		$info['adr']=$this->data_model->get_radr("address");
		$this->load->view('empdelivery',$info);
	
	}


	public function erhm()
	{
		
		$this->load->view('home');
	}

	public function demo()
	{
		
		$this->load->view('vicons');
	}



	public function staffreport()
	{
		$this->load->model('data_model');
		 $data['pickup']=$this->data_model->staffrepoview();
		// $data['delivery']=$this->data_model->staffrepoviewdeli();
		$this->load->view('adminstaffperfo',$data);
	}

	public function staffreport2()
	{
		$this->load->model('data_model');
		 //$data['pickup']=$this->data_model->staffrepoview();
		 $data['delivery']=$this->data_model->staffrepoviewdeli();
		$this->load->view('adminstaffperfodeli',$data);
	}



	public function daterepo()
	{
		
		$this->load->view('admindaterepo');
	}

	public function daterepores()
	{
		$dat2=$this->input->post('date1');
      
        $this->load->model('data_model');
        
		 
		$data['track']=$this->data_model->search_date($dat2);
		$this->load->view('admindatereporesult',$data);
	
		
	}


	public function sigp()
	{
		$temp['us']="";
		
		$this->load->view('sigup',$temp);
	}
	public function add()
	{
		$a=$this->input->post('youremail');
		$b=$this->input->post('reemail');
		$email=$this->input->post('youremail');

		if($a==$b)
		{
			$data=array('fname'=>$this->input->post('firstname'),
			'email'=>$this->input->post('youremail'),
			'pass'=>$this->input->post('password'),
			'utype'=>'c'
			// 'utype'=>$this->input->post('type')
			);







			$this->load->model('data_model');
			$res=$this->data_model->get_email($email);
			if($res==null)
			{
				$this->load->model('data_model');
		    	$this->data_model->insert_data("users",$data);
		        $this->load->view('signin');
			}
			else
			{
				echo "<script>alert('Email already exists please signin with a different one ')</script>";
				$temp['us']="";
				$this->load->view('sigup',$temp);
			}










		// 	$this->load->model('data_model');
		// 	$this->data_model->insert_data("users",$data);
		//    $this->load->view('signin');
		}
		// $data['fname'] = $this->input->post('firstname');
		// $data['lname'] = $this->input->post('lastname');
	else
	{
	$temp['us']="your email  doesnt match eachother ";
	$this->load->view('sigup',$temp);
	}
      
       
	}
	public function log()
	{
		$id=$this->input->post('email');
        $pass=$this->input->post('password');
        $this->load->model('data_model');
		
        $data['cust']=$this->data_model->get_user("users",$id,$pass,'c');
        $data['admin']=$this->data_model->get_user("users",$id,$pass,'a');
		$data['emp']=$this->data_model->get_user("users",$id,$pass,'e');
		
		$this->session->set_userdata(array('uname'=>$id));


        if($data['cust']!=null)
        {  
		//	$_SESSION['c_email'] = $id;
            $this->load->view('custhome');
			$this->session->set_userdata('user',$id);
        }
        else if($data['admin']!=null)
        {
			$this->session->set_userdata('adminemail',$id);

            //$this->session->set_userdata(array('user'=>$id));
			$_SESSION['email'] = $id;
			$this->load->model('data_model');
			$info =$this->data_model->get_count1();   
			$info1 =$this->data_model->get_count2();  
			$info2 =$this->data_model->get_count3();  
			$info3 =$this->data_model->get_count4();  
			
			
			$data = array('planet' => $info,'planet1' => $info1,'planet2' => $info2,'planet3' => $info3);
		  
			$this->load->view('adminhome',$data);
			
			//$this->session->set_userdata(array('user'=>$id)); 
        }
		else if($data['emp']!=null)
        {
			// $_SESSION['email'] = $id;
			// $_SESSION['password']=$pass;
			// $result = null;
			// foreach ($data['emp'] as $row) 
			// {
			// 	$result =$row;
			// 	break;
			// }
			
            // //$this->session->set_userdata(array('user'=>$id));
            // $this->load->view('emphome',$result);

			$this->session->set_userdata('employemail',$id);

			$this->load->model('data_model');
		$info =$this->data_model->get_count1();   
		$info1 =$this->data_model->get_count5();  
		$info2 =$this->data_model->get_count3();  
		$info3 =$this->data_model->get_count4();  
		
		
		$data = array('planet' => $info,'planet1' => $info1,'planet2' => $info2,'planet3' => $info3);
      
		$this->load->view('emphome',$data);
        }
        else
        {
           // $data['error'] = 'Your Account is Invalid';  
            $this->load->view('loginerr');  
        }
	}

	public function abut()
	{
		


		$id=$this->input->post('srch');
       
        $this->load->model('data_model');

		$info['adr']=$this->data_model->search_data("consig",$id);
		$this->load->view('about',$info);

		
	}

	public function empre()
	{
		$this->load->view('empreg');
	}
	public function reg()
	{
		$email=$this->input->post('email');
		$data1=array('empname'=>$this->input->post('empname'),
        'email'=>$this->input->post('email'),
        'empadr'=>$this->input->post('empadr'),
        'dob'=>$this->input->post('dob'),
		'empmobile'=>$this->input->post('empmobile'),
		'dob'=>$this->input->post('dob'),
		'gender'=>$this->input->post('gender'),
		'doj'=>$this->input->post('doj'),
		'pass'=>$this->input->post('password')
        );

		$data2=array('fname'=>$this->input->post('empname'),
        'email'=>$this->input->post('email'),
        'pass'=>$this->input->post('password'),
        'utype'=>'e'
        );
		
        $this->load->model('data_model');
		$res=$this->data_model->get_email($email);
		if($res==null)
		{
			$this->data_model->insert_data("employe",$data1);
			$this->data_model->insert_data("users",$data2);
			$this->load->model('data_model');
			$info =$this->data_model->get_count1();   
			$info1 =$this->data_model->get_count2();  
			$info2 =$this->data_model->get_count3();  
			$info3 =$this->data_model->get_count4();  
			
			
			$data = array('planet' => $info,'planet1' => $info1,'planet2' => $info2,'planet3' => $info3);
		  
			$this->load->view('adminhome',$data);
		}
		else
		{
			echo "<script>alert('Email already exists')</script>";
			$this->load->view('empreg');
		}
		
       

		
	}

	public function sadreg()
	{
		$this->load->helper('date');
		$da=date('d-m-y');
		$data3=array('aname'=>$this->input->post('cusname'),
        'adres'=>$this->input->post('adr'),
        'lmark'=>$this->input->post('lmark'),
        'mob'=>$this->input->post('num'),
		'altmob'=>$this->input->post('altnum'),
		'email'=>$this->input->post('email'),
		'availab'=>$this->input->post('availb'),
		'sdate'=>$da
		);
        $this->load->model('data_model');
        $this->data_model->insert_data("address",$data3);
	
		$this->load->view('custreceaddr');  
	}

	public function readreg()
	{
		
		$data=array('rname'=>$this->input->post('adname'),
        'radres'=>$this->input->post('adr'),
        'lmark'=>$this->input->post('lmark'),
        'mob'=>$this->input->post('mobile'),
		'altmob'=>$this->input->post('altmobile'),
		'email'=>$this->input->post('email'),
		'availab'=>$this->input->post('avail'),
		
		);
        $this->load->model('data_model');
        $this->data_model->insert_data("receiver",$data);
		$this->load->view('custconsigdet');
	}



	public function conreg()
	{
 
		$query ="select * from address order by aid DESC limit 1";
		$res = $this->db->query($query);
		$data=$res->result_array();
		foreach($data as $d)
		$sid=$d['aid'];

		$query ="select * from receiver order by rid DESC limit 1";
		$res = $this->db->query($query);
		$data=$res->result_array();
		foreach($data as $d)
		$rid=$d['rid'];
		

		$inme=$this->input->post('iname');
		$idescp=$this->input->post('desc');
		
		$da='0000-00-00';
		$data=array('iname'=>$this->input->post('iname'),
        'idesc'=>$this->input->post('desc'),
        'quantity'=>$this->input->post('qty'),
        'cat'=>$this->input->post('cat'),
		'status'=>'pending',
		'pymt'=>'pending',
		'deli_date'=>$da,
		'sid'=>$sid,  'rid'=>$rid

		
		);
        $this->load->model('data_model');
        $this->data_model->insert_data("consig",$data);
		

	
		                                                                 //conid displaying
		 $info['emp']=$this->data_model->get_idd($inme,$idescp);
		
	
		 $this->load->view('custconid',$info);
	}

	
	public function cnt()
	{
		
		$this->load->view('cntct');
	}
	public function vicons()
	{
		
		$this->load->view('vicons');
	}
	public function consig()
	{
		
		$this->load->view('consigmnt');
	}

	public function ctrack()
	{
		
		$this->load->view('custtrack');
	}

	public function pdemo()
	{
		
		$this->load->view('custpaydemo');
	}

	public function cpay()
	{
		 $id=$this->session->userdata('id');
		
		$this->load->model('data_model');
		// $data['track']=$this->data_model->custpaymnt($_SESSION['uname']);
		$data['track']=$this->data_model->custpaymnt($id);
		$this->load->view('custpayment',$data);

		
	}

	public function adminrepo()
	{
		$this->load->model('data_model');
		$data['track']=$this->data_model->consig_view();
		$this->load->view('adminrepo',$data);
		
	}

	public function emprepo()
	{
		$this->load->model('data_model');
		$data['track']=$this->data_model->consig_view();
		$this->load->view('empreport',$data);
		
	}

	public function admintrackconsig()
	{
	
		$this->load->view('admintrackconsig');
	}
	

	public function rece()
	{
		
		$this->load->view('rece');
	}
	public function sndadr()
	{
		
		$this->load->view('sndadr');
	}
	public function ser()
	{
		
		$this->load->view('serv');
	}
	public function sendnew()
	{
		
		$this->load->view('custsendconsig');
	}
	public function custreceadr()
	{
		
		$this->load->view('custreceaddr');
	}
	
	public function custconsig()
	{
		
		$this->load->view('custconsigdet');
	}
	

	public function emplist()
	{
		$this->load->model('data_model');
		$info['emp']=$this->data_model->get_data("employe");
		$this->load->view('emplist',$info);
	}



	public function adminhome()
	{

		if(!$this->session->userdata('adminemail'))
		{
			$this->load->view('signin');
		}
		else
		{

		$this->load->model('data_model');
		$info =$this->data_model->get_count1();   
		$info1 =$this->data_model->get_count2();  
		$info2 =$this->data_model->get_count3();  
		$info3 =$this->data_model->get_count4();  
		
		
		$data = array('planet' => $info,'planet1' => $info1,'planet2' => $info2,'planet3' => $info3);
      
		$this->load->view('adminhome',$data);

		}
		
	}




	public function custrack()
	{
		
		$id=$this->input->post('srch');
       
        $this->load->model('data_model');

		$info['adr']=$this->data_model->search_data("consig",$id);
		$this->load->view('custsrcres',$info);
	}

	public function emtrackk()
	{
		
		$id=$this->input->post('src');
       
        $this->load->model('data_model');

		$info['adr']=$this->data_model->search_data("consig",$id);
		$this->load->view('empsrcres',$info);
	}

	public function adminsrch()
	{
		
		$id=$this->input->post('srch');
       
        $this->load->model('data_model');

		$info['adr']=$this->data_model->search_data("consig",$id);
		$this->load->view('adminscrres',$info);
	}


	public function custhome()
	{
		if(!$this->session->userdata('user'))
		{
			$this->load->view('signin');
		}
		else
		{
			$this->load->view('custhome');
		}
	}


	public function emphome()
	{

		if(!$this->session->userdata('employemail'))
		{
			$this->load->view('signin');
		}
		else
		{
			
		



		$this->load->model('data_model');
		$info =$this->data_model->get_count1();   
		$info1 =$this->data_model->get_count5();  
		$info2 =$this->data_model->get_count3();  
		$info3 =$this->data_model->get_count4();  
		
		
		$data = array('planet' => $info,'planet1' => $info1,'planet2' => $info2,'planet3' => $info3);
      
		$this->load->view('emphome',$data);
		}
		
	}

	public function logout()  
    {  

		$this->session->sess_destroy();
		header('location:'.base_url().'login');
    }  



	
}
