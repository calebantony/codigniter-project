<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Data_model extends CI_Model 
{

	public function get_user($table,$id,$pass,$type)
	{
		$this->db->where(array('email'=>$id,'pass'=>$pass,'utype'=>$type));
		$res=$this->db->get($table);
		return $res->result_array();
	}

    public function insert_data($table,$data)
    {
        $this->db->insert($table,$data);
    }

	public function getDetails($table)
	{
		$result = $this->db->query("select * from users");
		return $result;
	}
	public function get_data($table)
	{
        $res=$this->db->get($table);
		return $res->result_array();
	}

	public function get_sadr($table)
	{


		$this->db->select('address.aname,address.adres,address.lmark,address.mob,address.altmob,address.email,address.availab,address.aid');
		$this->db->from('consig');
		$this->db->where('consig.status','pending');
		$this->db->join('address', 'consig.sid = address.aid');
		
		$result = $this->db->get()->result_array();
		//   var_dump($result);
		  return $result;


		// $res=$this->db->query("select * from address   ");
		// return $res->result_array();



	}

	public function get_radr($table)
	{

		$this->db->select('receiver.rname,receiver.radres,receiver.lmark,receiver.mob,receiver.altmob,receiver.email,receiver.availab,receiver.rid');
		$this->db->from('consig');
		$this->db->where('consig.status','processing delivery');
		$this->db->join('receiver', 'consig.rid = receiver.rid');
		
		$result = $this->db->get()->result_array();
		//   var_dump($result);
		  return $result;


		// $res=$this->db->query("select * from receiver ");
		// return $res->result_array();
	}



	public function getrate($table,$id)
	{
		$res=$this->db->query("select * from consig  where sid = $id ");
		return $res->result_array();
	}

	public function emplpickup($empmail)
	{

	
		$data=$this->db->query("SELECT empid from employe where email = '$empmail'");
		// echo $data;

		// return $data;

		//  return $res2->result_array();

		// $this->db->select('*');
		// // $this->db->from('employe');
		// $this->db->where('email',$empmail);
     	// $res=$this->db->get('employe');
	    // echo $res;
		// var_dump($data);
		 return $data->row();
	}

	public function consdetid($id)
	{
		 $res4=$this->db->query('SELECT cnid from consig where sid = "'.$id.'" ');
		//  var_dump ($res4);
		 return $res4->row();

		// $this->db->select('consig.cnid');
		// $this->db->from('consig');
		// $this->db->where('consig.sid=',$id);
     	// $res=$this->db->get();
		//  return $res;
	}


	public function consdetideli($id)
	{
		 $res4=$this->db->query('SELECT cnid from consig where rid = "'.$id.'" ');
		//  var_dump ($res4);
		 return $res4->row();

		
	}

	public function deliemptrack($cid,$emid)
	{

		$this->db->query("UPDATE track_emp SET delivery='$emid'  WHERE cid='$cid' ");
	
	}


	public function get_count1()
	{
		$r1= $this->db->count_all_results('consig');
	    return $r1;
		
	}
	public function get_count2()
	{
		
		 $r2= $this->db->count_all_results('Employe');
		return $r2;
		
	}
	public function get_count3()
	{
		
		$r3= $this->db->count_all_results('users');
		return $r3;
		
	}
	public function get_count4()
	{
		
		$r4= $this->db->count_all_results('address');
		return $r4;
		
	}
	public function get_count5()
	{
		
		$r5= $this->db->count_all_results('receiver');
		return $r5;
		
	}




	public function search_data($table,$id)
	{
		$res=$this->db->query("select * from consig  where cnid = $id ");
		return $res->result_array();
	}


	public function search_date($dat2)
	{
		// $res=$this->db->query("select * from consig  where deli_date = '$dat2' ");
		// return $res->result_array();


		$this->db->select('address.sdate,address.aname,address.adres,consig.iname,consig.quantity,receiver.rname,receiver.radres,consig.deli_date');
		$this->db->from('consig');
		$this->db->where(' consig.deli_date ',$dat2);
		$this->db->join('address', 'consig.sid = address.aid');
		$this->db->join('receiver', 'consig.rid = receiver.rid');
  
		$result = $this->db->get()->result_array();
		//var_dump($result);
		return $result;

	}
	public function get_email($email)
	{
		$this->db->where('email',$email);
		$res=$this->db->get("users");
		return $res->result_array();
	}

	public function custpaymnt($id)
	{
		 $res=$this->db->query("select * from consig  where pymt != 'pending'  AND  sid = '$id'");

		// $this->db->select('*');
		// $this->db->from('consig');
		// $this->db->join('address','consig.sid=address.aid');
		// $this->db->where('email',$id);
		// $res=$this->db->get();
		
		return $res->result_array();
	}
	

	public function get_idd($inme,$idescp)
	{
		$res=$this->db->query("select * from consig  where iname = '$inme' AND  idesc = '$idescp' ");
		return $res->result_array();
	}

	


	public function data_del($table,$id)
	{
        $this->db->where('empid',$id)->delete($table);
	}
	public function data_updat($table,$id)
	{
        $this->db->where('empid',$id);
		$res=$this->db->get($table);
		$data=$res->result_array();
		return $data[0];
	}
	public function data_update($table,$data,$id)
	{
        $this->db->where('empid',$id);
		$this->db->update($table,$data);
	}


	public function pymnt_update($table,$rate,$id)
	{

		$this->db->query("UPDATE consig SET pymt=$rate WHERE sid=$id ");
		$this->db->query("UPDATE consig SET status='processing delivery' WHERE sid=$id ");
     
	}


	public function deliupdate($id,$date4)
	{

		$this->db->query("UPDATE consig SET status='delivered'  WHERE rid=$id ");
		$this->db->query("UPDATE consig SET deli_date='$date4' WHERE rid=$id ");
		
     
	}


	public function consig_view()
	{
	  $this->db->select('address.sdate,address.aname,address.adres,consig.iname,consig.quantity,receiver.rname,receiver.radres');
	  $this->db->from('consig');
	  $this->db->join('address', 'consig.sid = address.aid');
	  $this->db->join('receiver', 'consig.rid = receiver.rid');

	  $result = $this->db->get()->result_array();
	  //var_dump($result);
	  return $result;
	}



	public function staffrepoview()
	{
	  $this->db->select('employe.empid,employe.empname,employe.email,consig.iname,consig.quantity,address.sdate,address.aname,address.adres');
	  $this->db->from('track');
	  $this->db->where('track.type','p');
	  $this->db->join('consig', 'consig.cnid = track.cid');
	  $this->db->join('employe', 'employe.empid = track.emp');
	  $this->db->join('address', 'consig.sid = address.aid');
	

	  $result = $this->db->get()->result_array();
	//   var_dump($result);
	//   return $result;
	  
	//   $this->db->select('employe.empid,employe.empname,employe.email');
	//   $this->db->from('track');
	//   $this->db->join('employe', 'employe.empid = track.emp');
	

	//   $result2 = $this->db->get()->result_array();
	//   var_dump($result);
	  return $result;
	//$add_attributes = array_merge($result, $result2);
	}

	public function staffrepoviewdeli()
	{
	  $this->db->select('employe.empid,employe.empname,employe.email,consig.iname,consig.quantity,consig.deli_date,receiver.rname,receiver.radres');
	  $this->db->from('track');
	  $this->db->where('track.type','d');
	  $this->db->join('consig', 'consig.cnid = track.cid');
	  $this->db->join('employe', 'employe.empid = track.emp');
	  $this->db->join('receiver', 'consig.rid = receiver.rid');
	

	  $result = $this->db->get()->result_array();
	//   var_dump($result);
	  return $result;
	}

	//$add_attributes = array_merge($data["reg_attrib"], $add_form);

}
