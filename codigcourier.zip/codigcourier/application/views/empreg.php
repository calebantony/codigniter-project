<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Welcome  Admin</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="<?php echo base_url();?>assets/admin/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="<?php echo base_url();?>assets/admin/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="<?php echo base_url();?>assets/admin/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />




 <!-- Icons font CSS-->
 <link href="<?php echo base_url();?>assets/vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="<?php echo base_url();?>assets/vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="<?php echo base_url();?>assets/vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="<?php echo base_url();?>assets/vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="<?php echo base_url();?>assets/css/main.css" rel="stylesheet" media="all">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <script type='text/javascript'>
  $(document).ready(function(){
      alert("hello");
    $('#email').change(function(){
    var email = $(this).val();
   alert(email);
    /*$.ajax({
     url:'<?php echo base_url();?>salon/checkTime',
     method: 'post',
     data: {timeslot: timeslot, date: date},
     //dataType: 'json',
     error: function() {
              alert('Something is wrong');
           },
     success: function(response){
       //alert(response);
       var len = response.length;
       if(len > 0){
         $('#status').text(response);

       }
 
     }
   });*/
  });
   </script>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Admin</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Admin is logged in  &nbsp;  </div>
        </nav>   
           <!-- /. NAV TOP  -->
           <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <img src="<?php echo base_url();?>assets/admin/img/find_user.png" class="user-image img-responsive"/>
					</li>
				
					
                    <li>
                        <a class="active-menu"  href="<?php echo base_url();?>Login/emphome"><i class="fa fa-dashboard fa-3x"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-sitemap fa-3x"></i> Manage Staff <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="<?php echo base_url();?>Login/emplist">staff List</a>
                            </li>
                            <li>
                                <a href="<?php echo base_url();?>Login/empre">Add new</a>
                            </li>
                            <li>
                                <a href="<?php echo base_url();?>Login/admineditemp">Edit staff  details</a>
                            </li>
                            </ul>
                            <li  >
                        <a  href=""><i class="fa fa-edit fa-3x"></i> Staff report  </a>
                        <ul class="nav nav-second-level">
                        <li>
                                <a href="<?php echo base_url();?>Login/staffreport">Pickup Report</a>
                            </li>
                            <li>
                                <a href="<?php echo base_url();?>Login/staffreport2">Delivery Report</a>
                            </li>
                           
                            </ul>


                    </li>
                    <li>
                        <a  href="<?php echo base_url();?>Login/admintrackconsig"><i class="fa fa-qrcode fa-3x"></i> Track a Consignment</a>
                    </li>
                    <li  >
                        <a   href="<?php echo base_url();?>Login/adminrepo"><i class="fa fa-bar-chart-o fa-3x"></i>All Reports</a>
                    </li>	
                    <li  >
                        <a  href="<?php echo base_url();?>Login/daterepo"><i class="fa fa-square-o fa-3x"></i> Date Wise Report </a>
                    </li>	
                	
                </ul>
               
            </div>
            
        </nav>   
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Employee details</h2>   
                        <h5>&nbsp </h5>
                        <h5>&nbsp Enter the  details of the employee. </h5>
                        <h5>&nbsp </h5>
                        <h5> &nbsp</h5>

                    </div>
                </div>
                 <!-- /. ROW  -->


                 <hr />


                 <form method="POST" action="<?php echo base_url();?>Login/reg" >
                    <div class="form-row">
                            <div class="name">Name</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="text" name="empname"  required>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Email id </div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="email" name="email"   id="email" required>
                                </div>
                            </div>
                        </div>

                        <div class="form-row m-b-55">
                            <div class="name">Adderss</div>
                            <div class="value">
                                <div class="row row-refine">
                                    <div class="col-9">
                                        <div class="input-group-desc">
                                            <input class="input--style-5" type="text" name="empadr"  required>
                                           
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="input-group-desc">
                                            <!-- <input class="input--style-5" type="text" name="phone"> -->
                                            <!-- <label class="label--desc">Phone Number</label> -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="form-row">
                            <div class="name">Date of birth </div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="date" name="dob"   required>
                                    <!-- <input type="date" id="birthday" name="birthday"> -->
                                </div>
                            </div>
                        </div>
                      
                        <div class="form-row">
                            <div class="name">Mobile  </div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="mobile number" name="empmobile"     pattern="[1-9]{1}[0-9]{9}"  required>
                                </div>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="name">Gender </div>
                            <div class="value">
                                <div class="input-group">
                                    <!-- <input class="input--style-5" type="email" name="email"> -->
                                    <div class="p-t-15">
                                <label class="radio-container m-r-55">Male
                                    <input type="radio" checked="checked" name="gender" value="m">
                                    <span class="checkmark"></span>
                                </label>
                                <label class="radio-container">Female
                                    <input type="radio" name="gender" value="f">
                                    <span class="checkmark"></span>
                                </label>
                            </div>
                                </div>
                            </div>
                        </div>
                       
                        <div class="form-row">
                            <div class="name">Date of Joining </div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="date" name="doj"   required>
                                    <!-- <input type="date" id="birthday" name="birthday"> -->
                                </div>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="name">Password  </div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="text" name="password"   required>
                                </div>
                            </div>
                        </div>

                   
                        <div>
                            <button class="btn btn--radius-2 btn--red" type="submit">ADD</button>
                        </div>
                    </form>








               
    </div>

    



    
             <!-- /. PAGE INNER  -->
              

            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="<?php echo base_url();?>assets/admin/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="<?php echo base_url();?>assets/admin/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="<?php echo base_url();?>assets/admin/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    
</body>
</html>
