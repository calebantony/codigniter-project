<?php
error_reporting(0);
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Employee portal </title>
	<!-- BOOTSTRAP STYLES-->
    <link href="<?php echo base_url();?>assets/admin/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="<?php echo base_url();?>assets/admin/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="<?php echo base_url();?>assets/admin/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

 <!-- Icons font CSS-->
 <link href="<?php echo base_url();?>assets/vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="<?php echo base_url();?>assets/vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="<?php echo base_url();?>assets/vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="<?php echo base_url();?>assets/vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="<?php echo base_url();?>assets/css/main.css" rel="stylesheet" media="all">



</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Employee</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> Employee is logged in  &nbsp;  </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <img src="<?php echo base_url();?>assets/admin/img/find_user.png" class="user-image img-responsive"/>
					</li>
				
					
                    <li>
                        <a class="active-menu"  href="<?php echo base_url();?>Login/emphome"><i class="fa fa-dashboard fa-3x"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-sitemap fa-3x"></i>Parcels <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                      
                            <li>
                                <a href="<?php echo base_url();?>Login/pickup">pick up</a>
                            </li>
                            <li>
                                <a href="<?php echo base_url();?>Login/delive">Delivery</a>
                            </li>
                            </ul>
                    <li>
                        <a  href="<?php echo base_url();?>Login/emptrack"><i class="fa fa-qrcode fa-3x"></i> Track a Consignment</a>
                    </li>
                    <li  >
                        <a   href="<?php echo base_url();?>Login/adminrepo"><i class="fa fa-bar-chart-o fa-3x"></i>All Reports</a>
                    </li>	
                    <li  >
                        <a  href="<?php echo base_url();?>Login/daterepo"><i class="fa fa-square-o fa-3x"></i> Date Wise Report </a>
                    </li>	
                     
                </ul>
               
            </div>
            
        </nav>  
        
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Parcel Details</h2>   
                     <h5>&nbsp </h5>
                  
                        <h5>Calculate the rate proceed . </h5>
                        <h5>&nbsp </h5>
                        <h5>&nbsp </h5>
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 <hr />
                 <h5>&nbsp </h5>
                
                 
                        <?php
                        foreach($adr as $e)
                        {?>
                        
                        <h3>Consignment   &nbsp:  &nbsp &nbsp<?php echo $e['iname'];?> </h3>
                        <h6>&nbsp </h6>
                        <h3>Description  &nbsp &nbsp  : &nbsp &nbsp<?php echo $e['idesc'];?> </h3>
                        <h6>&nbsp </h6>
                        <h3>Quantity   &nbsp  &nbsp &nbsp &nbsp &nbsp: &nbsp &nbsp<?php echo $e['quantity'];?> </h3>
                        <h6>&nbsp </h6>
                        <h3>Category  &nbsp &nbsp &nbsp &nbsp&nbsp: &nbsp &nbsp<?php echo $e['cat'];?> </h3>
                
    

                        
                        <?php } ?>
                        <h5>&nbsp </h5>
                        <h5>&nbsp </h5>
                        <h5>&nbsp </h5>

                        <form method="POST" action="<?php echo base_url();?>Login/enrate" >
                   


                      




                        <div class="form-row">
                            <div class="name"> &nbsp Enter charge  </div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="number" name="rate"  required>
                                </div>
                            </div>
                        </div>

                      

                      
                      
                       
                       
                   
                        <div>
                            <button class="btn btn--radius-2 btn--red" onclick="return confirm('Do you want to proceed with the entered amount ')" type="submit">Proceed </button>
                        </div>
                    </form>









    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="<?php echo base_url();?>assets/admin/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="<?php echo base_url();?>assets/admin/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="<?php echo base_url();?>assets/admin/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="<?php echo base_url();?>assets/admin/js/custom.js"></script>
    
   
</body>
</html>
