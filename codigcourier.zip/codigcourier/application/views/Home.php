<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="TemplateMo">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700" rel="stylesheet">

    <title>Courier Management System</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url();?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/fontawesome.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/templatemo-host-cloud.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/owl.css">
<!--

Host Cloud Template

https://templatemo.com/tm-541-host-cloud

-->
  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.html"><h2>Ship it  <em>  Courier Management System </em></h2></a>
          
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item active">
                <a class="nav-link" href="<?php echo base_url();?>Login">Home
                  <span class="sr-only">(current)</span>
                </a>
              </li>
              <!-- <li class="nav-item">
                <a class="nav-link" href="<?php echo base_url();?>Login/abut">About Us</a>
              </li> -->
              <!-- <li class="nav-item ">
                <a class="nav-link" href="<?php echo base_url();?>Login/ser">Our Services</a>
              </li> -->
             
              <li class="nav-item">
              <ul>
                <a class="nav-link" href="<?php echo base_url();?>Login/cnt">Contact Us</a>
              </li>
            </ul>

              <li class="nav-item dropdown">
                        <!-- <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Manage</a> -->
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo base_url();?>Login/empre">Employe Registration</a>
                            <a class="dropdown-item" href="<?php echo base_url();?>Login/sndadr">Send item </a>
                            <a class="dropdown-item" href="<?php echo base_url();?>Login/vicons">Update  consignment </a>
                  
                            <div class="dropdown-divider"></div>
                            </ul>
                            
                            </div>
                        
          </div>
          <div class="functional-buttons">
            <ul>
              <li><a href="<?php echo base_url();?>Login/sig">Log in</a></li>
              <li><a href="<?php echo base_url();?>Login/sigp">Sign Up</a></li>
            </ul>
          </div>
        </div>
      </nav>
    </header>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="banner">
      <div class="container">
        <div class="row">
          <div class="col-md-8 offset-md-2">
            <div class="header-text caption">
              <h2>Track your Consignment</h2>
              <div id="search-section">
              	<form id="suggestion_form" name="gs" method="post" action="<?php echo base_url();?>Login/abut">
                <div class="searchText">
                  
                  <input type="text" name="srch" class="searchText" placeholder="Enter your consignment id here..."  required>
                
                </div>
                    <input type="submit" name="results"  class="main-button" value="Search now ">
                 </form>
               <div class="advSearch_chkbox">
               </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Banner Ends Here -->

 

    <!-- Testimonials Starts Here -->
    <div class="testimonials-section">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <span>our  vision </span>
              <h2>We saves your pecious time </h2>
            </div>
          </div>
          <div class="col-md-10 offset-md-1">
            <div class="owl-testimonials owl-carousel">
              <div class="testimonial-item">
                <div class="icon">
                  <i class="fa fa-quote-right"></i>
                </div>
                <p>" we  reduces our valuable customers efforts of going on to the courier office for sending their products or consigment , we provide our pickup boys for picking up your consignment from your place and will be delivered to the receiver safely"</p>
               
              </div>
              <div class="testimonial-item">
                <div class="icon">
                  <i class="fa fa-quote-right"></i>
                </div>
                <p>"Better simplified user interface."</p>
                
              </div>
              <div class="testimonial-item">
                <div class="icon">
                  <i class="fa fa-quote-right"></i>
                </div>
                <p>"We keeps complete record of your transaction ."</p>
                
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Testimonials Ends Here -->


  <!-- Footer Starts Here -->
  <footer>
      <div class="container">
        <div class="row">
          <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="footer-item">
              <div class="footer-heading">
                <h2>About Us</h2>
              </div>
              <p>The courier management system is an online website which is developed for manageing the various activities which are invloved in the transaction of a courier item  .</p>
            </div>
          </div>
          
          <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="footer-item">
              <div class="footer-heading">
                <h2>Our services </h2>
              </div>
              <ul class="footer-list">
                <li><a href="#">Speed courier </a></li>
                <li><a href="#">Normal courier </a></li>
               
              </ul>
            </div>
          </div>
          
          
          
          <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="footer-item">
              <div class="footer-heading">
                <h2>More Information</h2>
              </div>
              <ul class="footer-list">
                <li>Phone: <a href="#">9072257568</a></li>
                <li>Email: <a href="#">mail@courier management.com</a></li>
    
                <li>Website: <a href="#">www.couriermanagement.com</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-12">
            <div class="sub-footer">
              
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!-- Footer Ends Here -->

    <!-- Bootstrap core JavaScript -->
    <script src="<?php echo base_url();?>assets/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Additional Scripts -->
    <script src="<?php echo base_url();?>assets/js/custom.js"></script>
    <script src="<?php echo base_url();?>assets/js/owl.js"></script>
    <script src="<?php echo base_url();?>assets/js/accordions.js"></script>


    <script language = "text/Javascript"> 
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t){                   //declaring the array outside of the
      if(! cleared[t.id]){                      // function makes it static and global
          cleared[t.id] = 1;  // you could use true and false, but that's more typing
          t.value='';         // with more chance of typos
          t.style.color='#fff';
          }
      }
    </script>

  </body>
</html>